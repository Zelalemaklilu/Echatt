// Supabase client - re-export from integrations
export { supabase } from '@/integrations/supabase/client';
